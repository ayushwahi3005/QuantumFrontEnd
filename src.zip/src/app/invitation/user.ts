export class User{
      id!:string;
	  firstName!:string;
	  lastName!:string;
	  email!:string;
	  companyId!:string;
	  companyName!:string;
	  mobileNumber!:string;
	  role!:string;
	  password!:string;


}