import { Component } from '@angular/core';

@Component({
  selector: 'app-workorder-category',
  templateUrl: './workorder-category.component.html',
  styleUrls: ['./workorder-category.component.css']
})
export class WorkorderCategoryComponent {

}
