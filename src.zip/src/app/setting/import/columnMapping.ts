export class ColumnMapping{
    
    excelColumn!:String;
    databaseColumn!:String;
    
  
}