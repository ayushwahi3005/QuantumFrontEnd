export enum SubscriptionPlan{
    MONTHLY = 'MONTHLY',
    ANNUAL = 'ANNUAL',
 


}