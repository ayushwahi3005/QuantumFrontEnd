export class Location{
    id!:string;
    companyId!:string;
    name!:string;
    parentLocation!:string;
    location!:string;
    apartment!:string;
    address!:string;
    city!:string;
    state!:string;
    status!:string;
    zipCode!:string;

    


}