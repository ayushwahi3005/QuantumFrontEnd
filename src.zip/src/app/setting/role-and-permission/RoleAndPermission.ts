export class RoleAndPermission{
    id!:string;
    name!:string;
    // assets!:string;
	// customers!:string;
    // workOrders!:string;
	// users!:string;
    // roleAndPermissions!:string;
	// imports!:string;
    // category!:string;
	// inventory!:string;
    type!:string;
    status!:string;
    ofUser!:Number;
    

}