export class CompanyInformation{
    id!:string;
    companyName!:string;
    comapanyLogo!:string;
    accountId!:string;
    address1!:string;
    address2!:string;
    city!:string;
    state!:string;
    
    zipCode!:string;
    phoneNo!:string;
    website!:string
  
}