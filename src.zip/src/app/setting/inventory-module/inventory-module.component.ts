import { Component } from '@angular/core';
import { ExtraFieldName } from './extraFieldName';
import { ShowFieldsData } from './showFieldsData';
import { MandatoryFields } from './mandatoryFields';
import { InventoryModuleService } from './inventory-module.service';

@Component({
  selector: 'app-inventory-module',
  templateUrl: './inventory-module.component.html',
  styleUrls: ['./inventory-module.component.css']
})
export class InventoryModuleComponent {

  extraFieldName!:ExtraFieldName[];
  addFieldName!:string;
  showFieldsList!:ShowFieldsData[];
  mandatoryFieldsList!:MandatoryFields[];
  mandatoryFieldsMap!:Map<string,boolean>;
  showFieldsMap!:Map<string,boolean>;
  extraFieldOption!:string;
  currOption:number=1;
  email!:any;
  editOn:boolean=true;
  deletionId:string='';
  deletionName!:string;
  showAlert: boolean = false; // Flag to toggle alert visibility
  alertMessage: string = ''; // Alert message
  alertType: string = 'success'; // Alert type: success, warning, error, etc.
  isSubscribedToEmailsMessage!:boolean;
  companyId!:any;
  mandatoryFields=[{
    name:"Part Image",
    dbName:"partImage",
    type:"file"
  },
  {
    name:"Part Id",
    dbName:"partId",
    type:"String"
  },
  {
    name:"Part Name",
    dbName:"partName",
    type:"Number"
  },
  {
    name:"Price",
    dbName:"price",
    type:"String"
  },
  {
    name:"Cost",
    dbName:"cost",
    type:"String"
  },
  {
    name:"Category",
    dbName:"category",
    type:"String"
  },
  {
    name:"Quantity",
    dbName:"quantity",
    type:"Option"
  },
  {
    name:"Company Id",
    dbName:"companyId",
    type:"Option"
  }]

  constructor(private inventoryModuleService:InventoryModuleService){}

  ngOnInit(){
    this.extraFieldOption="number";
    this.mandatoryFieldsMap = new Map<string, boolean>();
    this.showFieldsMap = new Map<string, boolean>();
    this.email=localStorage.getItem('user');
    this.companyId=localStorage.getItem('companyId');
    this.inventoryModuleService.getExtraFields(this.companyId).subscribe((data)=>{
      this.extraFieldName=data;
      console.log("--------extra------------->"+this.companyId);
      this.extraFieldName.forEach((x)=>{
        console.log(x.companyId+" "+x.name+" "+x.email)
      })
    },
    (err)=>{
      console.log(err);
    })

    this.inventoryModuleService.getAllMandatoryFields(this.companyId).subscribe((data)=>{
      this.mandatoryFieldsList=data;
      // console.log("mandatory----------------------->",this.mandatoryFieldsList)
      this.mandatoryFieldsList.forEach((x)=>{
        this.mandatoryFieldsMap.set(x.name,x.mandatory);
      })
    },
    (err)=>{
      console.log(err);
    })
    this.inventoryModuleService.getAllShowFields(this.companyId).subscribe((data)=>{
      this.showFieldsList=data;
      // console.log("show----------------------->",this.showFieldsList)
      this.showFieldsList.forEach((x)=>{
        this.showFieldsMap.set(x.name,x.show);
      })
    },
    (err)=>{
      console.log(err);
    })
  }

  onClick(option:number){
    this.currOption=option;
  }
  onAddField(){
    
   
    
    if(this.addFieldName==''||this.addFieldName==null){
      alert("Field Empty!!");
    }
    else{
    const obj={
      
      "name":this.addFieldName.trim(),
      "email":this.email,
       "type":this.extraFieldOption,
       "companyId":this.companyId
    }
    this.inventoryModuleService.addExtraFields(obj).subscribe((data)=>{this.extraFieldOption
      console.log(data);
    },
    (err)=>{
      console.log(err.error);
      // alert(err.error.errorMessage)
      this.triggerAlert(err.error.message,"danger");
    },
    ()=>{
      this.addFieldName='';
     
      this.extraFieldOption='number';
      this.ngOnInit();

    })
  }
  }
  removeExtraField(){
    this.inventoryModuleService.removeExtraField(this.deletionId).subscribe((data)=>{
      console.log(data);
      this.deletionId='';
    },
    (err)=>{
      console.log(err);
    },
    ()=>{
      this.ngOnInit();
      
    }
    )
    this.inventoryModuleService.deleteShowAndMandatoryFields(this.deletionName,this.companyId).subscribe((data)=>{
      console.log("deleted extra fields mandate and show");
    },
    (err)=>{
      console.log(err);
    },
    ()=>{
      this.ngOnInit();
      
    }
    )
  }
  updateDeletionName(name:string){
    this.deletionName=name;
  }
  addFieldOption(id:string){
    this.extraFieldOption=id;
  }
  removeFieldOption(){
    this.extraFieldOption='none';
  }
  updateDeleteId(id:string){
    this.deletionId=id;
  }
  updateFields(){

  }
  mandatoryField(event:any,name:string,type:string){
    console.log(event.checked);
    console.log(name);
    this.inventoryModuleService.getMandatoryFields(name,this.companyId).subscribe((data)=>{
      let obj;
      console.log(data);
      if(data==null){
        obj={
          "name":name,
          "email":this.email,
          "mandatory":event.checked,
          "type":type,
          "companyId":this.companyId
        }
        
      }
      else{
        obj={
          "id":data['id'],
          "name":name,
          "email":this.email,
          "mandatory":event.checked,
          "type":type,
          "companyId":this.companyId
        }
      }
      this.inventoryModuleService.mandatoryFields(obj).subscribe((data)=>{
        console.log("Updated");
        this.triggerAlert("SuccessFully Updated Field","success");
      },
      (err)=>{
        console.log(err);
      })
      
    })
  
  }
  onEditingShowAndMandatory(){
    
  }
  onEdit(){
    this.editOn=!this.editOn;
    if(this.editOn!=true){
      alert("Edit mode on");
    }
    else{
      alert("Saving Data");
    }
  }
  showField(event:any,name:string,type:string){
    
    console.log(event.checked);
    console.log(name);
    this.inventoryModuleService.getShowFields(name,this.companyId).subscribe((data)=>{
      let obj;
      console.log(data);
      if(data==null){
        obj={
          "name":name,
          "email":this.email,
          "show":event.checked,
          "type":type,
          "companyId":this.companyId
        }
        
      }
      else{
        obj={
          "id":data['id'],
          "name":name,
          "email":this.email,
          "show":event.checked,
          "type":type,
          "companyId":this.companyId
        }
      }
      this.inventoryModuleService.showFields(obj).subscribe((data)=>{
        console.log("Updated");
        this.triggerAlert("SuccessFully Updated Field","success");
      },
      (err)=>{
        console.log(err);
      })
      
    })
  }
  triggerAlert(message: string, type: string) {
    this.alertMessage = message;
    this.alertType = type;
    this.showAlert = true;
    // You can set a timeout to automatically hide the alert after a certain time
    setTimeout(() => {
      this.showAlert = false;
    }, 5000); // Hide the alert after 5 seconds (adjust as needed)
  }
  getValueOfMandatoryMap(name:string):boolean{
    if (this.mandatoryFieldsMap && this.mandatoryFieldsMap.has(name)) {
      return this.mandatoryFieldsMap.get(name) || false;
    }
    return false;
  }
  getValueOfShowMap(name:string):boolean{
    if (this.showFieldsMap && this.showFieldsMap.has(name)) {
      return this.showFieldsMap.get(name) || false;
    }
    return false;
  }
  print(){
    console.log(this.isSubscribedToEmailsMessage)
  }
  addFieldType(data:any){
    console.log(data);
    this.extraFieldOption=data;
  }
}
