export class CompanyInformation{
      id!:string;
	  customerEmail!:string;
	  companyName!:string;
	  comapanyLogo!:string;
	  website!:string;
	  phoneNo!:string;
	  address1!:string;
	  address2!:string;
	  city!:string;
	  state!:string;
	  zipCode!:string;


}