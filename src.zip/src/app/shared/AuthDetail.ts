export class AuthDetail{
	token!:string;
    role!:string;
}