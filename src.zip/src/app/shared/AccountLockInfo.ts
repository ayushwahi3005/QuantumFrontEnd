export class AccountLockInfo{
	id!:string;
    customerEmail!:string;
    lockedStatus!:boolean;
    incorrectAttemptCount!:number;

}