export class CompanyId{
    id!:string;
	companyName!:string;
}