export class Assets{
    id!:string;
    name!:string;
    serialNumber!:string;
    category!:string;
    customer!:string;
    location!:string;
    status!:string;
    image!:string;


}