export class CompanyCustomerFile{
    id!:string;
    assetId!:string;
    fileName!:string;
    file!:File;


}