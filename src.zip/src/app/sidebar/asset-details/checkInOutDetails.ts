export class CheckInOutDetails{
    
	date!:string;
	employee!:string;
	status!:string;
	notes!:string;
	location!:string;

  
}