export class QR{
    id!:string;
    custom!:string;
    optional!:string;
    type!:string;
    companyId!:string;
  
}