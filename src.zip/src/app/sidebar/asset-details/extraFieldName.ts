export class ExtraFieldName{
    id!:string;
    name!:string;
    email!:string;
    type!:string;
    companyId!:string;

  
}