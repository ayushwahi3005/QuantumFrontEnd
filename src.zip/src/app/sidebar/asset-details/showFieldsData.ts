export class ShowFieldsData{
    id!:string;
    name!:string;
    email!:string;
    show!:boolean;
    type!:string;
    companyId!:string;
  
}