export class User{
      id!:string;
	  firstName!:string;
	  lastName!:string;
	  email!:string;
	  companyId!:string;
	  mobileNumber!:string;
	  role!:string;


}