export class ExtraFields{
    id!:string;
    name!:string;
    value!:string;
    assetId!:string;
    type!:string;
}