export class ExtraField{
    id!:string;
    name!:string;
    value!:string;
    workorderId!:string;
    type!:string;
    companyId!:string;
  
}