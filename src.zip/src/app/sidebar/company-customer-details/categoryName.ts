export class CategoryName{
    id!:string;
    name!:string;
    email!:string;
    status!:string;
    companyId!:string;
  
}