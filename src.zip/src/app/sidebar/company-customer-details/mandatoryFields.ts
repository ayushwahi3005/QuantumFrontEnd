export class MandatoryFields{
    id!:string;
    name!:string;
    email!:string;
    mandatory!:boolean;
    type!:string;
    companyId!:string;
  
}