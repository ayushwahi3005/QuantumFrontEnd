export class PaginationResult{
    totalRecords!:number;
    data!:string[];
    

    


}