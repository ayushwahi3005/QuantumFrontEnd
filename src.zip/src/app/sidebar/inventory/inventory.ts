export class Inventory{
	id!:String;
	inventoryId!:number;
    partId!:string;
	partImage!:string;
    partName!:string;
	price!:number;
	cost!:number;
    category!:string;
	quantity!:number;
	companyId!:string;
}