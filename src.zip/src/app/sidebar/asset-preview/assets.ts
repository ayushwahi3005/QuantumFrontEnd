export class Assets{
    id!:string;
    name!:string;
    serialNumber!:string;
    category!:string;
    customer!:string;
    customerId!:string;
    location!:string;
    status!:string;
    image!:string;


}