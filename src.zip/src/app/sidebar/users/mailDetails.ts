export class MailDetails{
    email!:string;
    message!:string;
    role!:string;

}