export class ExtraField{
    id!:string;
    name!:string;
    value!:string;
    inventoryId!:string;
    type!:string;
    companyId!:string;
  
}