//environment keys
//environment keys
export const environment = {
    production: false,
    firebaseConfig: {
      apiKey: "AIzaSyB-Sc2phplqNbTyjVWJ6rziTfwMEF2xpU8",
    authDomain: "assetyug-da946.firebaseapp.com",
    projectId: "assetyug-da946",
    storageBucket: "assetyug-da946.appspot.com",
    messagingSenderId: "526139496135",
    appId: "1:526139496135:web:1d91fe51cbb1b22a2c10e2",
    measurementId: "G-BMRT81DWJT"
  
  
      },
      endpoint:"http://localhost:8080/"
  }